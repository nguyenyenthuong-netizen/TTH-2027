# TTH – 5 giao diện tương tác trên GitLab Pages Free

Bộ triển khai gồm 5 tệp HTML độc lập và trang danh mục dùng chung. Mọi giao diện nằm trong `public/`.

## Thiết lập lần đầu (miễn phí)
1. Đăng nhập GitLab.com và chọn gói Free; tạo một dự án mới, chọn Public nếu muốn mọi người truy cập cả mã nguồn và website.
2. Tải nội dung của tệp ZIP này lên **thư mục gốc** của dự án, giữ nguyên `.gitlab-ci.yml` và `public/` (không đặt cả bộ trong một thư mục con). Với tệp lớn như Website, cách ổn định là dùng `git push` từ máy tính.
3. Kiểm tra **Build → Pipelines** đến khi job `pages` thành công.
4. Mở **Deploy → Pages**, xác nhận mục "Access control" không giới hạn xem, lấy URL thật từ GitLab.
5. Trên website sẽ có 5 đường dẫn con: `khung-marketing/`, `trinh-chieu-marketing/`, `crm-da-kenh/`, `healthcare-app/`, `healthcare-website/`.

## Cập nhật
Thay tệp `public/<ten-muc>/index.html`, commit thay đổi rồi chạy lại pipeline. URL cũ không đổi. Nếu có thay đổi chức năng, cần kiểm tra lại ở từng thiết bị.

## Lưu ý
- Bộ này là trang HTML/JS tĩnh: có tương tác trình duyệt, **không** tự tạo cơ sở dữ liệu nhiều người dùng, phân quyền thực hay dịch vụ Contact Center.
- Không lưu dữ liệu bệnh nhân, dữ liệu khách hàng thật hoặc bí mật vào tệp HTML công khai.
- GitLab Free có giới hạn tài nguyên. Theo dõi dung lượng lưu trữ/compute và **không** bật gói hoặc dịch vụ trả phí.
- Bản quản trị Marketing vận hành thực tế là phần mềm khác; `trinh-chieu-marketing/` là bản HTML trình bày, không thay phần mềm quản trị vận hành.
- Nếu tạo dự án Private nhưng muốn Pages public, kiểm tra trạng thái Access control theo hướng dẫn GitLab.
